#include <iostream>
#include <string>
#include "missive.h"
#include "request.h"

using namespace std;

int main()
{
	request request1;
	request request2;
	missive missive1;
	request request2("Lt Eva", "Reinforcements", 10);
	
	
	return 0;
}